#1. Cargar y mostrar array:
# Declarar un array de 5 enteros. Cargarlo por teclado y mostrar su contenido por pantalla usando un
# ciclo for.

numeros = []
for i in range(5):
    numeros.append(i)

print(numeros)



